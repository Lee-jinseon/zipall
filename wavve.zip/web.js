// import http from 'http';
// import WebSocket from 'ws';
import express from 'express';
import morgan from 'morgan';   
import session from 'express-session';
import globalRouter from '/home/hosting_users/ljins622/apps/ljins622_ljins622/routers/globalRouter.js';
import userRouter from '/home/hosting_users/ljins622/apps/ljins622_ljins622/routers/userRouter.js';
import freeboardRouter from '/home/hosting_users/ljins622/apps/ljins622_ljins622/routers/freeboardRouter.js';
import { locals } from '/home/hosting_users/ljins622/apps/ljins622_ljins622/localsMiddleware.js';
import path from 'path';
const __dirname = path.resolve();


const PORT = 8001;
const app = express()          
const logger = morgan('dev') 

// const server = http.createServer(app) 
// const wss = new WebSocket.Server({server})

// const sockets = [];
// wss.on("connection", (socket)=>{ 
//     sockets.push(socket)
//     socket["nickname"] = "무명";
//     console.log("Connected to Browser");
//     socket.on("close", ()=>console.log("Disconnected to Browser"));
//     socket.on("message", (msg)=>{
//     const message = JSON.parse(msg);
//     switch(message.type) {
//         case "new_message":sockets.forEach((aSocket) => aSocket.send(`${socket.nickname}: ${message.payload}`)); break;
//         case "nickname":socket["nickname"]=message.payload; 
//     }
// });
// })


app.set('views', __dirname+'/home/hosting_users/ljins622/apps/ljins622_ljins622/views');                     
app.set('view engine', 'ejs');                     

app.use(express.static(__dirname+'/home/hosting_users/ljins622/apps/ljins622_ljins622/public'));       
app.use(logger)                                  
app.use(session({                                
    secret:"Hello!",                              
    resave:true,                                    
    saveUninitialized:true
}))         
app.use((req, res, next)=>{                          
    req.sessionStore.all((error, sessions)=>{        
        console.log(sessions)                
        next()                               
    })
})
app.use(locals)
app.use('/', globalRouter)            
app.use('/users', userRouter)
app.use('/freeboard', freeboardRouter)
                                    
const handleListening = () =>  console.log(`Server listening on port http://localhost:${PORT}`) 
app.listen(PORT, handleListening)
