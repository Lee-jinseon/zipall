// 슬릭슬라이더 플러그인 연결
$('.slideInner').slick({
    autoplay:true,
    autoplaySpeed:3000,
    speed:600,
    dots:true,
    prevArrow:'<button class="slick-arrow slick-prev"><i class="fa-solid fa-chevron-left"></i></button>',
    nextArrow:'<button class="slick-arrow slick-next"><i class="fa-solid fa-chevron-right"></i></button>',
    fade:false,
    slidesToShow:1,
    slidesToScroll:1,
    centerMode:true,
    centerPadding: '100px'
})

// 슬릭슬라이더 자동재생멈춤 버튼 연결
$('#section .plpa').on('click', function(){
    if ( $(this).find('i').hasClass('fa-pause') ) {
        $('.slideInner').slick("slickPause")
        $(this).find('i').removeClass('fa-pause').addClass('fa-play')
    } else {
        $('.slideInner').slick("slickPlay")
        $(this).find('i').removeClass('fa-play').addClass('fa-pause')
    }
})

// 마우스오버 아웃 이벤트
$('.movies li > div').on('mouseover mouseout', function(){
    $(this).toggleClass('on')
})

// gotop 일정높이 지나면 생겼다가 없어짐
$(window).on('scroll', function(){
    var sct = $(this).scrollTop()

    if (sct>100 && !$('html').hasClass('gotopflag')) {
        $('html').addClass('gotopflag')
        $('body').append('<div class="gotop"><a href="javascript:;"><i class="fa-solid fa-circle-chevron-up"></i></a></div>')
        $('.gotop').css({
            position:'fixed',
            right:'250px',
            bottom:'50px',
            fontSize:'50px',
            zIndex:999,
            opacity:'0',
            color: '#fbceb1'
        }).animate({opacity:1}, 300)
    } else if (sct<=100 && $('html').hasClass('gotopflag')) {
        $('html').removeClass('gotopflag')
        $('.gotop').animate({opacity:0}, 300, function(){
            $(this).remove()
        })
    }
    
})


$('body').on('click', '.gotop', function(){
    $('html').animate({
        scrollTop:0
    }, 500)
})


// contents 애니메이션
AOS.init();