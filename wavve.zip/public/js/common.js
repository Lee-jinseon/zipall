// 호버시 depth2 보기

$('.depth1 > li').hover(function(){
  $(this).find('.depth2').toggle();
})

// 검색하기를 누르면 새로운 창

$(".btn-search").click(function(){
    $("#popup").fadeIn();
});
$("#popup .exit").click(function(){
    $("#popup").fadeOut();
});


