export const locals = (req, res, next) => {     
    res.locals.loggedIn = Boolean(req.session.loggedIn) 
    res.locals.userid = req.session.userid      
    next()
}