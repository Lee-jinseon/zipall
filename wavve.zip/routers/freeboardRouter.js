import express from 'express';
import { list, write, writing, view, edit, editing, remove, pagegroup } from '/home/hosting_users/ljins622/apps/ljins622_ljins622/controllers/freeboardController.js'
const freeboardRouter = express.Router();

freeboardRouter.get('/list', list)
freeboardRouter.route('/write').get(write).post(writing)
freeboardRouter.get('/view', view)
freeboardRouter.route('/edit').get(edit).post(editing)
freeboardRouter.get('/remove', remove)
freeboardRouter.get('/pagegroup', pagegroup)

export default freeboardRouter
