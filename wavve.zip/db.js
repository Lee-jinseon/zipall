import mysql from 'mysql';  
export const db = mysql.createConnection({ 
    host : 'ljins622.cafe24app.com',  
    user : 'ljins622',       
    password : 'dbsrl468356!',
    database : 'ljins622'     
})
db.connect()

// import mysql from 'mysql';  
// export const db = mysql.createConnection({ 
//     host : '앱생성할때 만들어진 도메인',  
//     user : '카페24 node js 호스팅 아이디',       
//     password : '호스팅 신청 시 FTP, SSH, DB 비밀번호',
//     database : '카페24 node js 호스팅 아이디'     
// })
// db.connect()

